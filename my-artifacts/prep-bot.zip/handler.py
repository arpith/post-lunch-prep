import json
import zulip

def hello(event, context):
    client = zulip.Client(config_file="~/zuliprc-dev")

    topic = "some topic"
    link = "https://woooo"

    message = """
Hi 

Today's topic will be {Topic}!

Today's resource on our topic can be found (here)[{link}]. Please do give it a read through if you'd like to refresh your understanding and see some code samples!

The questions will be projected in the Mainspace from 1:45 PM to 2:45 PM. The leftmost question will tend to be more introductory, while the rightmost question will typically have a more involved implementation.
    """.format(topic=topic, link=link)

    message = """
    For those following along, today's questions are:

    1) https://leetcode.com/problems/can-place-flowers/description/
    2) https://leetcode.com/problems/set-matrix-zeroes/description/

    Please feel free to join us in Turing @ 2:45 PM for our discussion!
    """

    message = """
    Our post-lunch prep discussion will be in Turing in 10 minutes!

    Please come join regardless of whether you have completed, or even attempted, the questions :)

    If you have a solution you would like to present or discuss, please do PM it to me any time.
    """

    # Send a stream message
    request = {
        "type": "stream",
        "to": "445 Broadway",
        "subject": "Post-lunch Prep!",
        "content": message
    }
    result = client.send_message(request)
    print(result)